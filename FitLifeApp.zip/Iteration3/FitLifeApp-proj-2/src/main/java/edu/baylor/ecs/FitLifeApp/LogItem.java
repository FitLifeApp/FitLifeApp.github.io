package edu.baylor.ecs.FitLifeApp;

public class LogItem {

}
