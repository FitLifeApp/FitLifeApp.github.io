package edu.baylor.ecs.FitLifeApp;

public abstract class LogItem {
	protected static int count = 0;
	
}
